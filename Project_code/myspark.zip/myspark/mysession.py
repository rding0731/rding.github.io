import random
import base64
import getpass
import ftplib
import pyspark
import pandas as pd
import pyspark.sql.functions as F
from pyspark.sql.dataframe import DataFrame
from pyspark.rdd import RDD
from pyspark.sql.readwriter import DataFrameReader
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType
from myspark.mydataframe import myDataFrame
#from myspark.sas.sas7bdat import SAS7BDATReader
from pandas.io.sas.sas7bdat import SAS7BDATReader
from myspark.mainframe import copybook
from myspark.mainframe import ebcdic

def mapTypes(types, dic={}):
    return [dic[t] if t in dic else StringType() for t in types]

def createSchema(names, types=[], dic={}):
    if not types:
        sparkTypes = mapTypes(names)
    elif types and dic:
        sparkTypes = mapTypes(types, dic)
    else:
        sparkTypes = types
    
    fields = [StructField(n,t) for n,t in zip(names,sparkTypes)]
    return StructType(fields)

def createStringSchema(pdf):
    #fields = [StructField(field, StringType()) for field in pdf.columns.values]
    return createSchema(pdf.columns.values)

def updateSchema(pdf, df):
    for name in pdf.columns.values:
        if pdf[name].dtype == int:
            df = df.withColumn(name, df[name].cast("integer"))
        elif pdf[name].dtype == float:
            df = df.withColumn(name, df[name].cast("double"))
        else:
            df = df.withColumn(name, F.trim(df[name]))
    return df

def layout2schema(layout):
    schema = StructType()
    for row in layout:
        if row.datatype.find('Integer') != -1:
            schema.add(row.name, IntegerType())
        elif row.datatype.find('Decimal') != -1:
            schema.add(row.name, DoubleType())
        else:
            schema.add(row.name, StringType())
    return schema

class pwdManager(object):
    def __init__(self, pwdFile='', username='', password=''):
        self.fortune = ["Would you like to play a game?","The Matrix has you","I'm afraid I can't do that","All your base are belong to us","Does Not Compute","I'll be back"]
        self._pwdFile = pwdFile
        if self._pwdFile:
            with open(self._pwdFile) as f:
                c = {k:v for k,v in [l.strip().split('=') for l in f.readlines()]}
            self._username = base64.b64encode(c[username].encode())
            self._password = base64.b64encode(c[password].encode())
        else:
            self._username = base64.b64encode(getpass.getpass(prompt='Enter your username: ').encode())
            self._password = base64.b64encode(getpass.getpass(prompt='Enter your password: ').encode())
            print('Accepted')
            
    def __repr__(self):
        return random.choice(self.fortune)
            
class myDataFrameReader(DataFrameReader):
    def __init__(self, sqlContext):
        DataFrameReader.__init__(self, sqlContext)

    def _df(self, jdf):
        return myDataFrame(jdf, self._sqlContext)
        
class HiveContext(pyspark.sql.HiveContext):
    def __init__(self, sparkContext):
        pyspark.sql.HiveContext.__init__(self, sparkContext)
        
    def getMaxRecord(self, lrecl):
        gib = (2**10)**3
        mem = self._sc._conf.get('spark.driver.memory')
        maxLimit = gib*int(mem[:-1])
        multiplier = 12
        recSize = lrecl*multiplier
        return int(maxLimit/recSize)
        
    def sql(self, sqlQuery):
        return myDataFrame(self._ssql_ctx.sql(sqlQuery), self)

    @property
    def read(self):
        return myDataFrameReader(self)
    
    def createDataFrame(self, data, schema=None, samplingRatio=None):
        if isinstance(data, DataFrame):
            raise TypeError("data is already a DataFrame")

        if isinstance(data, RDD):
            rdd, schema = self._createFromRDD(data, schema, samplingRatio)
        else:
            rdd, schema = self._createFromLocal(data, schema)
        jrdd = self._jvm.SerDeUtil.toJavaArray(rdd._to_java_object_rdd())
        jdf = self._ssql_ctx.applySchemaToPythonRDD(jrdd.rdd(), schema.json())
        df = myDataFrame(jdf, self)
        df._schema = schema
        return df
    
    def createFromPandas(self, pdf):
        pdf.fillna('', inplace=True)
        schema = createStringSchema(pdf)
        df = self.createDataFrame(pdf, schema)
        return updateSchema(pdf, df)
    
    def createFromExcel(self, file, sheet):
        xl = pd.ExcelFile(file)
        pdf = xl.parse(sheet)
        return self.createFromPandas(pdf)
    
    def createFromTeradata(self, pwd, sqlQuery, url="jdbc:teradata://edwcop1.gso.aexp.com/logmech=ldap"):
        teraProperties = {"driver":"com.teradata.jdbc.TeraDriver", "user":base64.b64decode(pwd._username).decode(), "password":base64.b64decode(pwd._password).decode()}
        teraQuery = "({}) as tmp".format(sqlQuery)
        return self.read.jdbc(url, teraQuery, properties=teraProperties)
    
    def _collectAsRDD(self, it, lrecl):
        maxRecord = self.getMaxRecord(lrecl)
        i = 0
        buf = []
        ldf = []
        
        for record in it:
            i += 1
            buf.append(tuple(record))
        
            if i >= maxRecord:
                ldf.append(self._sc.parallelize(buf))
                i = 0
                buf = []
                
        ldf.append(self._sc.parallelize(buf))
        return self._sc.union(ldf)
    
    def _createInChunks(self, it, schema, lrecl):
        rdd = self._collectAsRDD(it, lrecl)
        jrdd = self._jvm.SerDeUtil.toJavaArray(rdd._to_java_object_rdd())
        jdf = self._ssql_ctx.applySchemaToPythonRDD(jrdd.rdd(), schema.json())
        df = myDataFrame(jdf, self)
        df._schema = schema
        return df

    def createFromSAS(self, file):
        first = True
        rdr = SAS7BDATReader(file, encoding='iso-8859-1')
        maxRecord = self.getMaxRecord(sum(rdr._column_data_lengths))
        rdr.chunksize = maxRecord
        for chunk in rdr:
            if first:
                df = self.createFromPandas(chunk)
                first = False
            else:
                df.unionAll(self.createFromPandas(chunk))
        return df
    
    def createFromMainframe(self, pwd, filename, cpybk, server='dipe.ipc.us.aexp.com'):
        ftp = ftplib.FTP(server, base64.b64decode(pwd._username).decode(), base64.b64decode(pwd._password).decode())
        layout, lrecl = copybook.process_remote(ftp, cpybk)
        schema = layout2schema(layout)
        it = ebcdic.convert_chunk(ftp, filename, lrecl, layout)
        df = self._createInChunks(it, schema, lrecl)
        ftp.quit()
        return df

"""
Placeholder for Spark 2.0

class SparkSession(pyspark.sql.SparkSession):
    def __init__(self, sparkContext, jsparkSession=None):
        pyspark.sql.SparkSession__init__(self, sparkContext, jsparkSession)

    def sql(self, sqlQuery):
        return myDataFrame(self._jsparkSession.sql(sqlQuery), self._wrapped)
        
    @property
    def read(self):
        return myDataFrameReader(self._wrapped)

"""
