import array
import ftplib
import ssl

codepage = 'cp500'
residualChunk = b''

def zoned2num(z):
    a = array.array('B', z)
    v = 0

    for i in a:
        v = (v * 10) + (i & 0xf)

    if (a[-1] & 0xf0) == 0xd0:
        v = -v

    return v

def packed2num(p):
    a = array.array('B', p)
    v = 0

    for i in a[:-1]:
        v = (v * 100) + (((i & 0xf0) >> 4) * 10) + (i & 0xf)

    i = a[-1]
    v = (v * 10) + ((i & 0xf0) >> 4)
    if (i & 0xf) == 0xd:
        v = -v

    return v


### functions for binary local file

def yield_records(input_file, record_length):
    rec_bytes = input_file.read(record_length)
    while rec_bytes:
        yield rec_bytes
        rec_bytes = input_file.read(record_length)

def convert_record(line, layout, cp=codepage):
    record = dict()
    for name, start, size, percision, datatype in layout:
        field = line[start:start+size]
        if datatype == 'Char':
            record[name] = field.decode(cp).strip()
        else:
            if datatype.find('Packed') != -1:
                value = packed2num(field)
            else:
                value = zoned2num(field)

            if datatype.find('Decimal') != -1:
                value = value/10**percision

            record[name] = value

    return record

def convert_file(filename, lrecl, layout, cp=codepage):
    with open(filename,'rb') as inf:
        for record in yield_records(inf, lrecl):
            yield convert_record(record, layout, cp)

### functions for binary remote mainframe file

def yieldBinary(ftpContext, cmd, blocksize=8192, rest=None):
    ftpContext.voidcmd('TYPE I')
    conn = ftpContext.transfercmd(cmd, rest)
    try:
        while 1:
            data = conn.recv(blocksize)
            if not data:
                break
            yield data
        # shutdown ssl layer
        if isinstance(conn, ssl.SSLSocket):
            conn.unwrap()
    finally:
        conn.close()
    return ftpContext.voidresp()

def yield_chunks(l, n):
    """Yield successive n-sized chunks from l."""
    for i in range(0, len(l), n):
        yield l[i:i + n]

def convert_chunk(ftpContext, filename, lrecl, layout, cp=codepage):
    residual = b''
    for data in yieldBinary(ftpContext, "RETR " + filename):
        chunks = residual + data
        for chunk in yield_chunks(chunks, lrecl):
            if len(chunk) == lrecl:
                yield convert_record(chunk, layout)
        if len(chunk) == lrecl:
            residual = b''
        else:
            residual = chunk
