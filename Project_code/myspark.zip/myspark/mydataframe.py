import sys
import pandas as pd
import pyspark
import pyspark.sql.functions as F
from fileinput import input
from glob import glob
from shutil import rmtree
from collections import OrderedDict
from pyspark.sql.dataframe import DataFrame
from pyspark.rdd import RDD
from pyspark.sql.readwriter import DataFrameReader
from pyspark.sql.column import Column
from pyspark.sql.types import Row
from pyspark.sql.window import Window
from pyspark.serializers import BatchedSerializer, PickleSerializer, AutoBatchedSerializer

def seqFunc(u, v):
    u['cnt'] += 1
    u['sum'] += v
    return u

def combFunc(u1, u2):
    u1['cnt'] += u2['cnt']
    u1['sum'] += u2['sum']
    return u1

class myRDD(RDD):
    def __init__(self, jrdd, ctx, jrdd_deserializer=AutoBatchedSerializer(PickleSerializer())):
        RDD.__init__(self, jrdd, ctx, jrdd_deserializer)
        
    def toDataFrame(self):
        return self.map(lambda x: Row(**dict(x))).toDF()

class myDataFrame(DataFrame):
    def __init__(self, jdf, sql_ctx):
        DataFrame.__init__(self, jdf, sql_ctx)
        
    @property
    def rdd(self):
        if self._lazy_rdd is None:
            jrdd = self._jdf.javaToPython()
            self._lazy_rdd = myRDD(jrdd, self.sql_ctx._sc, BatchedSerializer(PickleSerializer()))
        return self._lazy_rdd
    
    def coalesce(self, numPartitions):
        return myDataFrame(self._jdf.coalesce(numPartitions), self.sql_ctx)
    
    def repartition(self, numPartitions):
        return myDataFrame(self._jdf.repartition(numPartitions), self.sql_ctx)

    def repartition(self, numPartitions, *cols):
        if isinstance(numPartitions, int):
            if len(cols) == 0:
                return myDataFrame(self._jdf.repartition(numPartitions), self.sql_ctx)
            else:
                return myDataFrame(
                    self._jdf.repartition(numPartitions, self._jcols(*cols)), self.sql_ctx)
        elif isinstance(numPartitions, (basestring, Column)):
            cols = (numPartitions, ) + cols
            return myDataFrame(self._jdf.repartition(self._jcols(*cols)), self.sql_ctx)
        else:
            raise TypeError("numPartitions should be an int or Column")
    
    def distinct(self):
        return myDataFrame(self._jdf.distinct(), self.sql_ctx)
    
    def sample(self, withReplacement, fraction, seed=None):
        assert fraction >= 0.0, "Negative fraction value: %s" % fraction
        seed = seed if seed is not None else random.randint(0, sys.maxsize)
        rdd = self._jdf.sample(withReplacement, fraction, long(seed))
        return myDataFrame(rdd, self.sql_ctx)
    
    def sampleBy(self, col, fractions, seed=None):
        if not isinstance(col, str):
            raise ValueError("col must be a string, but got %r" % type(col))
        if not isinstance(fractions, dict):
            raise ValueError("fractions must be a dict but got %r" % type(fractions))
        for k, v in fractions.items():
            if not isinstance(k, (float, int, long, basestring)):
                raise ValueError("key must be float, int, long, or string, but got %r" % type(k))
            fractions[k] = float(v)
        seed = seed if seed is not None else random.randint(0, sys.maxsize)
        return myDataFrame(self._jdf.stat().sampleBy(col, self._jmap(fractions), seed), self.sql_ctx)
    
    def randomSplit(self, weights, seed=None):
        for w in weights:
            if w < 0.0:
                raise ValueError("Weights must be positive. Found weight value: %s" % w)
        seed = seed if seed is not None else random.randint(0, sys.maxsize)
        rdd_array = self._jdf.randomSplit(_to_list(self.sql_ctx._sc, weights), long(seed))
        return [myDataFrame(rdd, self.sql_ctx) for rdd in rdd_array]
    
    def alias(self, alias):
        assert isinstance(alias, basestring), "alias should be a string"
        return myDataFrame(getattr(self._jdf, "as")(alias), self.sql_ctx)
    
    def join(self, other, on=None, how=None):
        if on is not None and not isinstance(on, list):
            on = [on]

        if on is None or len(on) == 0:
            jdf = self._jdf.join(other._jdf)
        elif isinstance(on[0], basestring):
            if how is None:
                jdf = self._jdf.join(other._jdf, self._jseq(on), "inner")
            else:
                assert isinstance(how, basestring), "how should be basestring"
                jdf = self._jdf.join(other._jdf, self._jseq(on), how)
        else:
            assert isinstance(on[0], Column), "on should be Column or list of Column"
            if len(on) > 1:
                on = reduce(lambda x, y: x.__and__(y), on)
            else:
                on = on[0]
            if how is None:
                jdf = self._jdf.join(other._jdf, on._jc, "inner")
            else:
                assert isinstance(how, basestring), "how should be basestring"
                jdf = self._jdf.join(other._jdf, on._jc, how)
        return myDataFrame(jdf, self.sql_ctx)
    
    def sortWithinPartitions(self, *cols, **kwargs):
        jdf = self._jdf.sortWithinPartitions(self._sort_cols(cols, kwargs))
        return myDataFrame(jdf, self.sql_ctx)
    
    def sort(self, *cols, **kwargs):
        jdf = self._jdf.sort(self._sort_cols(cols, kwargs))
        return myDataFrame(jdf, self.sql_ctx)

    """"
    def describe(self, *cols):
        if len(cols) == 1 and isinstance(cols[0], list):
            cols = cols[0]
        jdf = self._jdf.describe(self._jseq(cols))
        return myDataFrame(jdf, self.sql_ctx)
    """

    def select(self, *cols):
        jdf = self._jdf.select(self._jcols(*cols))
        return myDataFrame(jdf, self.sql_ctx)
    
    def selectExpr(self, *expr):
        if len(expr) == 1 and isinstance(expr[0], list):
            expr = expr[0]
        jdf = self._jdf.selectExpr(self._jseq(expr))
        return myDataFrame(jdf, self.sql_ctx)
    
    def filter(self, condition):
        if isinstance(condition, basestring):
            jdf = self._jdf.filter(condition)
        elif isinstance(condition, Column):
            jdf = self._jdf.filter(condition._jc)
        else:
            raise TypeError("condition should be string or Column")
        return myDataFrame(jdf, self.sql_ctx)
    
    def unionAll(self, other):
        return myDataFrame(self._jdf.unionAll(other._jdf), self.sql_ctx)
    
    def intersect(self, other):
        return myDataFrame(self._jdf.intersect(other._jdf), self.sql_ctx)
    
    def subtract(self, other):
        return myDataFrame(getattr(self._jdf, "except")(other._jdf), self.sql_ctx)
    
    def dropDuplicates(self, subset=None):
        if subset is None:
            jdf = self._jdf.dropDuplicates()
        else:
            jdf = self._jdf.dropDuplicates(self._jseq(subset))
        return myDataFrame(jdf, self.sql_ctx)
    
    def dropna(self, how='any', thresh=None, subset=None):
        if how is not None and how not in ['any', 'all']:
            raise ValueError("how ('" + how + "') should be 'any' or 'all'")

        if subset is None:
            subset = self.columns
        elif isinstance(subset, basestring):
            subset = [subset]
        elif not isinstance(subset, (list, tuple)):
            raise ValueError("subset should be a list or tuple of column names")

        if thresh is None:
            thresh = len(subset) if how == 'any' else 1

        return myDataFrame(self._jdf.na().drop(thresh, self._jseq(subset)), self.sql_ctx)
    
    def fillna(self, value, subset=None):
        if not isinstance(value, (float, int, long, basestring, dict)):
            raise ValueError("value should be a float, int, long, string, or dict")

        if isinstance(value, (int, long)):
            value = float(value)

        if isinstance(value, dict):
            return myDataFrame(self._jdf.na().fill(value), self.sql_ctx)
        elif subset is None:
            return myDataFrame(self._jdf.na().fill(value), self.sql_ctx)
        else:
            if isinstance(subset, basestring):
                subset = [subset]
            elif not isinstance(subset, (list, tuple)):
                raise ValueError("subset should be a list or tuple of column names")

            return myDataFrame(self._jdf.na().fill(value, self._jseq(subset)), self.sql_ctx)

    def replace(self, to_replace, value, subset=None):
        if not isinstance(to_replace, (float, int, long, basestring, list, tuple, dict)):
            raise ValueError(
                "to_replace should be a float, int, long, string, list, tuple, or dict")

        if not isinstance(value, (float, int, long, basestring, list, tuple)):
            raise ValueError("value should be a float, int, long, string, list, or tuple")

        rep_dict = dict()

        if isinstance(to_replace, (float, int, long, basestring)):
            to_replace = [to_replace]

        if isinstance(to_replace, tuple):
            to_replace = list(to_replace)

        if isinstance(value, tuple):
            value = list(value)

        if isinstance(to_replace, list) and isinstance(value, list):
            if len(to_replace) != len(value):
                raise ValueError("to_replace and value lists should be of the same length")
            rep_dict = dict(zip(to_replace, value))
        elif isinstance(to_replace, list) and isinstance(value, (float, int, long, basestring)):
            rep_dict = dict([(tr, value) for tr in to_replace])
        elif isinstance(to_replace, dict):
            rep_dict = to_replace

        if subset is None:
            return myDataFrame(self._jdf.na().replace('*', rep_dict), self.sql_ctx)
        elif isinstance(subset, basestring):
            subset = [subset]

        if not isinstance(subset, (list, tuple)):
            raise ValueError("subset should be a list or tuple of column names")

        return myDataFrame(
            self._jdf.na().replace(self._jseq(subset), self._jmap(rep_dict)), self.sql_ctx)
    
    def crosstab(self, col1, col2):
        if not isinstance(col1, str):
            raise ValueError("col1 should be a string.")
        if not isinstance(col2, str):
            raise ValueError("col2 should be a string.")
        return myDataFrame(self._jdf.stat().crosstab(col1, col2), self.sql_ctx)
    
    def withColumn(self, colName, col):
        assert isinstance(col, Column), "col should be Column"
        return myDataFrame(self._jdf.withColumn(colName, col._jc), self.sql_ctx)
    
    def withColumnRenamed(self, existing, new):
        return myDataFrame(self._jdf.withColumnRenamed(existing, new), self.sql_ctx)
    
    def drop(self, col):
        if isinstance(col, basestring):
            jdf = self._jdf.drop(col)
        elif isinstance(col, Column):
            jdf = self._jdf.drop(col._jc)
        else:
            raise TypeError("col should be a string or a Column")
        return myDataFrame(jdf, self.sql_ctx)
    
    def toDF(self, *cols):
        jdf = self._jdf.toDF(self._jseq(cols))
        return DataFrame(jdf, self.sql_ctx)
    
    def asOrderedDict(self, recursive=False):
        if not hasattr(self, "__fields__"):
            raise TypeError("Cannot convert a Row class into dict")

        if recursive:
            def conv(obj):
                if isinstance(obj, Row):
                    return asOrderedDict(obj, True)
                elif isinstance(obj, list):
                    return [conv(o) for o in obj]
                elif isinstance(obj, dict):
                    return dict((k, conv(v)) for k, v in obj.items())
                else:
                    return obj
            return OrderedDict(zip(self.__fields__, (conv(o) for o in self)))
        else:
            return OrderedDict(zip(self.__fields__, self))
        
    def procFreq(self, col):
        window = Window.partitionBy().rowsBetween(-sys.maxsize,sys.maxsize)
        cnt = self.groupBy(col).count()
        ttl = cnt.withColumn('total', F.sum(F.col('count')).over(window))
        return ttl.withColumn('percentage', F.format_string("%3.1f%%", F.col('count')/F.col('total')*100))
        
    def countAndSumByKey(self, col, key):
        pairrdd = self.rdd.map(lambda x:(x[key],x[col]))
        aggrdd = pairrdd.aggregateByKey({'cnt':0, 'sum':0.0}, lambda x, y: seqFunc(x, y), lambda x, y: combFunc(x, y))
        flatrdd = aggrdd.map(lambda x: (x[0], x[1]['cnt'], x[1]['sum']))
        header = [key, 'cnt_'+col, 'sum_'+col]
        return flatrdd.toDF(header)
    
    def write_csv(self, fileName, header=False):
        fields = self.rdd.first().__fields__
        tempName = fileName+'.tmp'
        self.write.format('com.databricks.spark.csv').save(tempName)
        with open(fileName, 'w') as f:
            if header:
                f.write(','.join(fields)+'\n')
            f.write(''.join(input(glob(tempName + "/part-*"))))
        rmtree(tempName)